<?php

/**
 * @author Marcio Figueredo 
 * @copyright Copyright (c) 2026
 */
header("Location: /projeto/index.php");
exit();
?>