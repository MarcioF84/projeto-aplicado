const pagesConfig = {
    'page-form-login': {
        title: 'Início',
        onLoad: () => {
            loadPage('page-form-login', 'form_login.php');
        }
    },
    'page-form-add-user': {
        title: 'Novo Cadastro',
        onLoad: () => {
            loadPage('page-form-add-user', 'form_add_user.php');
        }
    },
    'page-form-alt-user': {
        title: 'Atualizar Cadastro',
        onLoad: () => {
            loadPage('page-form-alt-user', 'form_alt_user.php');
        }
    },
    'page-list-user': {
        title: 'Lista de Usuários',
        onLoad: () => {
            loadPage('page-list-user', 'list_user.php');
            renderTable({
                entidade: 'Usuario',
                tabelaId: 'data-table-body-usuarios',
                colunas: ['id_usuario', 'nome', 'email'],
                actions: [
                    { label: '✏️', title: 'Editar', onClick: 'loadData' },
                    { label: '❌', title: 'Remover', onClick: 'removeData' }
                ]
            });
        }
    }
};

function toggleMenu() {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('overlay').classList.toggle('active');
}

function navigate(page) {

    const current = document.getElementById(page);
    const title = document.getElementById('page-title');

    document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));

    if (current) {
        current.classList.remove('hidden');
    }

    // if (window.innerWidth <= 768) toggleMenu();

    const config = pagesConfig[page] || { title: 'Início' };
    title.innerText = config.title;

    if (config.onLoad) {
        config.onLoad();
    }
}

function loadPage(pageId, file) {
    const container = document.getElementById(pageId);

    if (container.dataset.loaded) return; // evita recarregar

    fetch(file)
        .then(res => res.text())
        .then(html => {
            container.innerHTML = html;
            container.dataset.loaded = true;
        });
}

function showLoading(message = 'Carregando...') {
    const modal = document.getElementById('modal');
    const text = document.getElementById('modal-message');

    text.innerText = message;
    modal.classList.remove('hidden');
}

function hideLoading() {
    document.getElementById('modal').classList.add('hidden');
}

function renderTable({ entidade, tabelaId, colunas, actions = [] }) {

    const co = btoa(entidade + '_Control');
    const ac = btoa(entidade + '_Gerencia');

    showLoading('Carregando dados...');

    fetch(`/projeto/app/Core/Router.php?co=${co}&ac=${ac}`)
        .then(response => response.json())
        .then(res => {

            if (!res.success) {
                alert(res.error);
                return;
            }

            const dados = res.data.data;
            const tbody = document.getElementById(tabelaId);
            tbody.innerHTML = '';

            if (!dados || dados.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="${colunas.length + 1}" style="text-align:center">
                            Nenhum dado encontrado.
                        </td>
                    </tr>
                `;
                return;
            }

            dados.forEach(item => {
                let row = '<tr>';
                colunas.forEach(col => {
                    row += `<td>${item[col] ?? ''}</td>`;
                });
                let actionsHtml = '<ul>';

                actions.forEach(action => {
                    actionsHtml += `
                            <li><button onclick="${action.onClick}(${item.id_usuario})" title="${action.title}">${action.label}</button></li>
                    `;
                });
                actionsHtml += '</ul>';
                row += `<td>${actionsHtml}</td>`;
                row += '</tr>';
                tbody.innerHTML += row;
            });
        })
        .catch(err => console.error(err))
        .finally(() => hideLoading());
}

function waitForElement(id) {
    return new Promise(resolve => {
        const interval = setInterval(() => {
            const el = document.getElementById(id);
            if (el) {
                clearInterval(interval);
                resolve(el);
            }
        }, 50);
    });
}

async function loadData(id) {

    try {
        showLoading('Carregando...');

        const co = btoa('Usuario_Control');
        const ac = btoa('Usuario_Gerencia');

        const response = await fetch(`/projeto/app/Core/Router.php?co=${co}&ac=${ac}&id_usuario=${id}`);
        const res = await response.json();

        if (!res.success) {
            showLoading(res.error || 'Erro ao buscar usuário');
            return;
        }

        const user = res.data.data[0];

        //navega para o form
        navigate('page-form-alt-user');

        //aguarda o form carregar (IMPORTANTE)
        await waitForElement('alt_nome');

        //preenche os campos
        document.getElementById('alt_nome').value = user.nome || '';
        document.getElementById('alt_telefone').value = user.telefone || '';
        document.getElementById('alt_sexo').value = user.sexo || '';
        document.getElementById('alt_id_tipo_usuario').value = user.id_tipo_usuario || '';
        document.getElementById('alt_bio').value = user.bio || '';

        // guarda o ID para update
        document.getElementById('form-alt-user').dataset.id = user.id_usuario;

    } catch (err) {
        console.error(err);
        showLoading('Erro inesperado');
    } finally {
        hideLoading();
    }
}

async function saveChangeData(event) {
    event.preventDefault();
    const form = event.target;

    try {
        showLoading('Salvando...');

        const payload = {
            co: btoa('Usuario_Control'),
            ac: btoa('Usuario_Alt'),
            id_usuario: form.dataset.id,
            nome: document.getElementById('alt_nome').value,
            telefone: document.getElementById('alt_telefone').value,
            sexo: document.getElementById('alt_sexo').value,
            id_tipo_usuario: document.getElementById('alt_id_tipo_usuario').value,
            bio: document.getElementById('alt_bio').value
        };

        // Requisição
        const response = await fetch('/projeto/app/Core/Router.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        const res = await response.json();

        if (!res.success) {
            showLoading(res.error || 'Erro ao salvar');
            return;
        }

        // Sucesso
        showLoading(res.data?.message || 'Salvo com sucesso!');

        // Limpa formulário
        event.target.reset();

    } catch (err) {
        console.error(err);
        showLoading('Erro inesperado');
    } finally {
        setTimeout(() => {
            hideLoading();
        }, 2000);
    }
}

async function saveNewData(event) {
    event.preventDefault();

    try {
        showLoading('Salvando...');

        const payload = {
            co: btoa('Usuario_Control'),
            ac: btoa('Usuario_Add'),

            nome: document.getElementById('nome').value,
            email: document.getElementById('email').value,
            senha: document.getElementById('senha').value,
            telefone: document.getElementById('telefone').value,
            sexo: document.getElementById('sexo').value,
            id_tipo_usuario: document.getElementById('id_tipo_usuario').value,
            bio: document.getElementById('bio').value
        };

        // Requisição
        const response = await fetch('/projeto/app/Core/Router.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        const res = await response.json();

        if (!res.success) {
            showLoading(res.error || 'Erro ao salvar');
            return;
        }

        // Sucesso
        showLoading(res.data?.message || 'Salvo com sucesso!');

        // Limpa formulário
        event.target.reset();

    } catch (err) {
        showLoading('Erro inesperado');
    } finally {
        setTimeout(() => {
            hideLoading();
        }, 2000);
    }
}

async function removeData(id) {

    try {
        showLoading('Revomendo...');

        const payload = {
            co: btoa('Usuario_Control'),
            ac: btoa('Usuario_Desativar'),
            id_usuario: id
        };

        // Requisição
        const response = await fetch('/projeto/app/Core/Router.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        const res = await response.json();

        if (!res.success) {
            showLoading(res.error || 'Erro ao salvar');
            return;
        }

        // Sucesso
        showLoading(res.data?.message || 'Salvo com sucesso!');

        renderTable({
            entidade: 'Usuario',
            tabelaId: 'data-table-body-usuarios',
            colunas: ['id_usuario', 'nome', 'email'],
            actions: [
                { label: '✏️', title: 'Editar', onClick: 'loadData' },
                { label: '❌', title: 'Remover', onClick: 'removeData' }
            ]
        });

    } catch (err) {
        showLoading('Erro inesperado');
    } finally {
        setTimeout(() => {
            hideLoading();
        }, 2000);
    }
}

window.onload = function () {
    loadPage('page-form-login', 'form_login.php');
    lucide.createIcons();
};