<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MF</title>
    <link rel="stylesheet" href="inc/site.css">
</head>

<body>

    <div id="overlay" class="overlay" onclick="toggleMenu()"></div>

    <nav id="sidebar">
        <div class="nav-header">Meu App</div>
        <ul>
            <li><button onclick="navigate('page-form-login')"><i data-lucide="home"></i> Início</button></li>            
            <li><button onclick="navigate('page-list-user')"><i data-lucide="table"></i> Usuários</button></li>
        </ul>
    </nav>

    <main>
        <header>
            <button class="menu-toggle" onclick="toggleMenu()">☰</button>
            <h1 id="page-title">Início</h1>
        </header>

        <section class="content">
            <!-- Página Login -->
            <div id="page-form-login" class="card page"></div>

            <!-- Formulário Novo Cadastro -->
            <div id="page-form-add-user" class="card page hidden"></div>

            <!-- Formulário Atualizar Cadastro -->
            <div id="page-form-alt-user" class="card page hidden"></div>

            <!-- Página Usuários -->
            <div id="page-list-user" class="table-container page hidden"></div>

            <div id="modal" class="modal hidden">
                <div class="modal-content">
                    <p id="modal-message">Salvando...</p>
                </div>
            </div>
        </section>
    </main>
    <script src="inc/lucide.min.js"></script>
    <script src="inc/site.js" defer></script>
</body>

</html>