<table>
    <thead>
        <tr>
            <th>#</th>
            <th>Nome</th>
            <th>E-mail</th>
            <th>Ação</th>
        </tr>
    </thead>
    <tbody id="data-table-body-usuarios">
        <tr>
            <td colspan="3" style="text-align:center">Nenhum dado.</td>
        </tr>
    </tbody>
</table>